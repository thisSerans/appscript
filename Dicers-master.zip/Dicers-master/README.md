# Google Apps Script Project: Dicers
This repo (Dicers) was automatically created on 28 January 2019 10:42:33 GMT by GasGit
for more information see the [desktop liberation site](https://ramblings.mcpher.com/drive-sdk-and-github/getting-your-apps-scripts-to-github/ "desktop liberation")
you can see [library and dependency information here](dependencies.md)

Now update manually with details of this project - this skeleton file is committed only when there is no README.md in the repo.
